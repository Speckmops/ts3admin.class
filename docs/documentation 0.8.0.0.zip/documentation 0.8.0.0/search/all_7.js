var searchData=
[
  ['instanceedit',['instanceEdit',['../classts3admin.html#ab61659f34a4df47d95bda4c1c030755c',1,'ts3admin']]],
  ['instanceinfo',['instanceInfo',['../classts3admin.html#a6d166c9029376686209303c5ce5bdbe9',1,'ts3admin']]]
];
